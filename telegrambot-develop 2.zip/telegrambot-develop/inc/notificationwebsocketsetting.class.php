<?php
/*
 -------------------------------------------------------------------------
 TelegramBot plugin for GLPI
 Copyright (C) 2017 by the TelegramBot Development Team.

 https://github.com/pluginsGLPI/telegrambot
 -------------------------------------------------------------------------

 LICENSE

 This file is part of TelegramBot.

 TelegramBot is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 TelegramBot is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with TelegramBot. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

if (!defined('GLPI_ROOT')) {
   die("Sorry. You can't access this file directly");
}

/**
 * This class manages the SMS notifications settings
 */
class PluginTelegrambotNotificationWebsocketSetting extends NotificationSetting {

   static function getTypeName($nb = 0) {
      return __('Telegram followups configuration', 'telegrambot');
   }

   public function getEnableLabel() {
      return __('Enable followups via Telegram', 'telegrambot');
   }

   static public function getMode() {
      return Notification_NotificationTemplate::MODE_WEBSOCKET;
   }

   function showFormConfig($options = []) {
      global $CFG_GLPI;

      // Obtém as configurações do bot
      $bot_token = PluginTelegrambotBot::getConfig('token');
      $bot_username = PluginTelegrambotBot::getConfig('bot_username');

      // Início do formulário de configuração
      $form = "<form action='" . Toolbox::getItemTypeFormURL(__CLASS__) . "' method='post'>";
      $form .= "<div>";
      $form .= "<table class='tab_cadre_fixe'>";
      $form .= "<tr class='tab_bg_1'><th colspan='4'>" . _n('Telegram notification', 'Telegram notifications', Session::getPluralNumber()) . "</th></tr>";

      // Campo para o Bot Token
      $form .= "<tr class='tab_bg_2'>";
      $form .= "<td>" . __('Bot token') . "</td><td>";
      $form .= "<input type='text' name='token' value='" . htmlspecialchars($bot_token, ENT_QUOTES) . "' style='width: 100%'>";
      $form .= "</td><td colspan='2'>&nbsp;</td></tr>";

      // Campo para o Bot Username
      $form .= "<tr class='tab_bg_2'>";
      $form .= "<td>" . __('Bot username') . "</td><td>";
      $form .= "<input type='text' name='bot_username' value='" . htmlspecialchars($bot_username, ENT_QUOTES) . "' style='width: 100%'>";
      $form .= "</td><td colspan='2'>&nbsp;</td></tr>";

      // Exibe o formulário
      echo $form;
      $this->showFormButtons($options);
   }

}
