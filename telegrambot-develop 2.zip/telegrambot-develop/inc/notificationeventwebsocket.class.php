<?php
/*
 -------------------------------------------------------------------------
 TelegramBot plugin for GLPI
 Copyright (C) 2017 by the TelegramBot Development Team.

 https://github.com/pluginsGLPI/telegrambot
 -------------------------------------------------------------------------

 LICENSE

 This file is part of TelegramBot.

 TelegramBot is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 TelegramBot is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with TelegramBot. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

class PluginTelegrambotNotificationEventWebsocket
      extends NotificationEventAbstract
      implements NotificationEventInterface {

   // Método para obter o nome do campo de destino
   static public function getTargetFieldName() {
      return 'users_id';
   }

   // Método para obter o campo de destino e garantir sua existência nos dados fornecidos
   static public function getTargetField(&$data) {
      $field = self::getTargetFieldName();

      // Garante que o campo seja inicializado se não estiver definido
      if (!isset($data[$field])) {
         $data[$field] = null;  // Inicializa o campo como null se não estiver presente
      }

      return $field;
   }

   // Desabilita o cron para este evento específico
   static public function canCron() {
      return false;
   }

   // Indica que não há dados administrativos a serem retornados
   static public function getAdminData() {
      return false;
   }

   // Indica que não há dados administrativos específicos da entidade
   static public function getEntityAdminsData($entity) {
      return false;
   }

   // Método de envio de notificação, que não deve ser chamado
   static public function send(array $data) {
      // Adiciona uma mensagem de log para indicar que este método não deve ser usado
      Toolbox::logDebug(__METHOD__ . ' should not be called!');
      return false;
   }
}
