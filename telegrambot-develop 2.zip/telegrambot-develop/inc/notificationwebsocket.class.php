<?php
/*
 -------------------------------------------------------------------------
 TelegramBot plugin for GLPI
 Copyright (C) 2017 by the TelegramBot Development Team.

 https://github.com/pluginsGLPI/telegrambot
 -------------------------------------------------------------------------

 LICENSE

 This file is part of TelegramBot.

 TelegramBot is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 TelegramBot is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with TelegramBot. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

class PluginTelegrambotNotificationWebsocket implements NotificationInterface {

   // Verifica se o valor está correto (lógica de validação pode ser adicionada)
   static function check($value, $options = []) {
      return true; // Retorna true como padrão, pode ser aprimorado
   }

   // Método para testar a notificação
   static function testNotification() {
      // TODO: Implementar lógica de teste para a notificação
   }

   // Envia a notificação para o destinatário especificado
   function sendNotification(array $options = []) {
      // Verifica se as chaves necessárias estão presentes nas opções
      if (empty($options['to']) || empty($options['content_text'])) {
         Toolbox::logDebug('sendNotification: Missing required parameters.');
         return false; // Retorna false se os parâmetros obrigatórios não estiverem definidos
      }

      $to = $options['to'];
      $content = $options['content_text'];

      // Chama o método para enviar a mensagem
      PluginTelegrambotBot::sendMessage($to, $content);
      return true; // Retorna true após o envio bem-sucedido
   }

}
