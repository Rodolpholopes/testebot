<?php
/*
 -------------------------------------------------------------------------
 TelegramBot plugin for GLPI
 Copyright (C) 2017 by the TelegramBot Development Team.

 https://github.com/pluginsGLPI/telegrambot
 -------------------------------------------------------------------------

 LICENSE

 This file is part of TelegramBot.

 TelegramBot is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 TelegramBot is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with TelegramBot. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

class PluginTelegrambotCron {

   static function getTypeName($nb=0) {
      return 'TelegramBot';
   }

   static function cronInfo($name) {
      switch ($name) {
         case 'messagelistener':
            return array('description' => __('Handles incoming bot messages', 'telegrambot'));
         default:
            return array();  // Retorna um array vazio para tipos desconhecidos, evitando erros
      }
   }

   static function cronMessageListener($task) {
      // Inicializa variáveis
      $success = 0;
      $message = '';

      // Captura o retorno do método para processar mensagens
      try {
         $response = PluginTelegrambotBot::getUpdates();
         
         if ($response === 'ok') {
            $success = 1;
            $message = 'Action successfully completed';
         } else {
            $message = "Error: $response";  // Formata a mensagem de erro de forma clara
         }
      } catch (Exception $e) {
         // Captura possíveis exceções e loga o erro detalhado
         $message = 'Exception encountered: ' . $e->getMessage();
         error_log("Erro no cronMessageListener: " . $e->getTraceAsString());
      }

      // Loga a mensagem final e retorna o status de sucesso
      $task->log($message);
      return $success;
   }

}
