<?php
/*
 -------------------------------------------------------------------------
 TelegramBot plugin for GLPI
 Copyright (C) 2017 by the TelegramBot Development Team.

 https://github.com/pluginsGLPI/telegrambot
 -------------------------------------------------------------------------

 LICENSE

 This file is part of TelegramBot.

 TelegramBot is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 TelegramBot is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with TelegramBot. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

define('PLUGIN_TELEGRAMBOT_VERSION', '2.0.0');

/**
 * Initialize the hooks of the plugin.
 * This function is required for the plugin to operate correctly.
 *
 * @return void
 */
function plugin_init_telegrambot() {
    global $PLUGIN_HOOKS;

    // Enable CSRF compliance for the plugin
    $PLUGIN_HOOKS['csrf_compliant']['telegrambot'] = true;

    // Add hooks for various plugin functionalities
    $PLUGIN_HOOKS['post_item_form']['telegrambot'] = 'add_username_field';
    $PLUGIN_HOOKS['item_add']['telegrambot'] = array('User' => array('PluginTelegrambotUser', 'item_add_user'));
    $PLUGIN_HOOKS['pre_item_update']['telegrambot'] = array('User' => array('PluginTelegrambotUser', 'item_update_user'));

    // Check if the plugin is activated and register the notification mode
    $plugin = new Plugin();

    if ($plugin->isActivated('telegrambot')) {
        Notification_NotificationTemplate::registerMode(
            Notification_NotificationTemplate::MODE_WEBSOCKET,
            __('Telegram', 'plugin_telegrambot'),
            'telegrambot'
        );
    }
}

/**
 * Get the name and the version of the plugin.
 * This function is required for the plugin to provide metadata.
 *
 * @return array An associative array containing plugin information.
 */
function plugin_version_telegrambot() {
    return [
        'name'           => 'TelegramBot',
        'version'        => PLUGIN_TELEGRAMBOT_VERSION,
        'author'         => '<a href="http://trulymanager.com" target="_blank">Truly Systems</a>',
        'license'        => 'GPLv2+',
        'homepage'       => 'https://github.com/pluginsGLPI/telegrambot',
        'minGlpiVersion' => '9.2'
    ];
}

/**
 * Check pre-requisites before installation.
 * This function is optional but recommended to ensure compatibility.
 *
 * @return boolean True if prerequisites are met, false otherwise.
 */
function plugin_telegrambot_check_prerequisites() {
    // Check GLPI version compatibility
    if (version_compare(GLPI_VERSION, '9.2', 'lt')) {
        if (method_exists('Plugin', 'messageIncompatible')) {
            echo Plugin::messageIncompatible('core', '9.2');
        } else {
            echo "This plugin requires GLPI >= 9.2";
        }
        return false;
    }
    return true;
}

/**
 * Check the configuration of the plugin.
 *
 * @param boolean $verbose Whether to display a message on failure. Defaults to false.
 *
 * @return boolean True if configuration is correct, false otherwise.
 */
function plugin_telegrambot_check_config($verbose = false) {
    // Placeholder for your configuration check logic
    if (true) { // Replace with actual checks
        return true;
    }

    if ($verbose) {
        _e('Installed / not configured', 'telegrambot');
    }
    return false;
}
