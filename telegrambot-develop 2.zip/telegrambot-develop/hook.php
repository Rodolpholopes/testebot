<?php
/*
 -------------------------------------------------------------------------
 TelegramBot plugin for GLPI
 Copyright (C) 2017 by the TelegramBot Development Team.

 https://github.com/pluginsGLPI/telegrambot
 -------------------------------------------------------------------------

 LICENSE

 This file is part of TelegramBot.

 TelegramBot is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 TelegramBot is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with TelegramBot. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 */

/**
 * Plugin install process
 *
 * @return boolean
 */
function plugin_telegrambot_install() {
   global $DB;

   // Execute the installation SQL script and handle potential errors
   if (!$DB->runFile(GLPI_ROOT . '/plugins/telegrambot/db/install.sql')) {
      // Log error if the SQL script fails
      error_log('Failed to execute install.sql for TelegramBot plugin.');
      return false;
   }

   // Set default configuration values
   Config::setConfigurationValues('core', ['notifications_websocket' => 0]);
   Config::setConfigurationValues('plugin:telegrambot', ['token' => '', 'bot_username' => '']);

   // Register cron task and handle potential errors
   if (!CronTask::register(
      'PluginTelegrambotCron',
      'messagelistener',
      5 * MINUTE_TIMESTAMP,
      array('comment' => '', 'mode' => CronTask::MODE_EXTERNAL)
   )) {
      // Log error if the cron task registration fails
      error_log('Failed to register the cron task for TelegramBot plugin.');
      return false;
   }

   return true;
}

/**
 * Plugin uninstall process
 *
 * @return boolean
 */
function plugin_telegrambot_uninstall() {
   global $DB;

   // Execute the uninstall SQL script
   if (!$DB->runFile(GLPI_ROOT . '/plugins/telegrambot/db/uninstall.sql')) {
      // Log error if the SQL script fails
      error_log('Failed to execute uninstall.sql for TelegramBot plugin.');
      return false;
   }

   // Remove configuration values
   $config = new Config();
   $config->deleteConfigurationValues('core', ['notifications_websocket']);
   $config->deleteConfigurationValues('plugin:telegrambot', ['token', 'bot_username']);

   return true;
}

/**
 * Adds a username field for users
 *
 * @param array $params
 */
function add_username_field(array $params) {
   $item = $params['item'];

   if ($item->getType() == 'User') {
      PluginTelegrambotUser::showUsernameField($item);
   }
}
