<?php
/**
 * This is the console commands configuration for the Robo task runner.
 * 
 * @see http://robo.li/
 * 
 * This file sets up the configuration for Robo tasks related to the GLPI project.
 */

require_once 'vendor/autoload.php';

/**
 * Class RoboFile
 * 
 * This class extends the base RoboFile from GLPI and allows you to define
 * your own custom Robo commands and configurations for the project.
 */
class RoboFile extends Glpi\Tools\RoboFile
{
    // Array of files for code style checking
    protected $csfiles = ['./', 'setup.php.tpl', 'hook.php.tpl'];

    // You can define your own commands or configurations here.
    
    /**
     * Example command to run tests.
     *
     * @task test
     */
    public function test()
    {
        $this->say("Running tests...");
        // Add your testing logic here
    }

    /**
     * Example command to clean the project.
     *
     * @task clean
     */
    public function clean()
    {
        $this->say("Cleaning project...");
        // Add your cleaning logic here
    }

    // Add more custom commands as needed
}
