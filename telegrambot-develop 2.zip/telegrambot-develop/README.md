# Telegram Bot for GLPI

![GLPI Banner](https://user-images.githubusercontent.com/29282308/31666160-8ad74b1a-b34b-11e7-839b-043255af4f58.png)

[![License GPL 3.0](https://img.shields.io/badge/License-GPL%203.0-blue.svg)](./license)
[![Project Status: Active](http://www.repostatus.org/badges/latest/active.svg)](http://www.repostatus.org/#active)
[![Telegram Group](https://img.shields.io/badge/Telegram-Group-blue.svg)](https://telegram.me/tgbotglpi)
[![Github All Releases](https://img.shields.io/github/downloads/pluginsGLPI/telegrambot/total.svg)](http://plugins.glpi-project.org/#/plugin/telegrambot)
[![Follow Twitter](https://img.shields.io/badge/Twitter-GLPI%20Project-26A2FA.svg)](https://twitter.com/GLPI_PROJECT)
[![Conventional Commits](https://img.shields.io/badge/Conventional%20Commits-1.0.0-yellow.svg)](https://conventionalcommits.org)

## Table of Contents

- [Synopsis](#synopsis)
- [Build Status](#build-status)
- [Installation](#installation)
- [Documentation](#documentation)
- [Versioning](#versioning)
- [Contact](#contact)
- [Professional Services](#professional-services)
- [Contribute](#contribute)
- [Copying](#copying)

## Synopsis

The TelegramBot for GLPI allows you to receive notifications on Telegram whenever a ticket is created in GLPI, keeping you updated on your IT infrastructure.

## Build Status

| **Release Channel** | **Beta Channel** |
|:--------------------:|:-----------------:|
| [![Travis CI build](https://api.travis-ci.org/pluginsGLPI/telegrambot.svg?branch=master)](https://travis-ci.org/pluginsGLPI/telegrambot/) | [![Travis CI build](https://api.travis-ci.org/pluginsGLPI/telegrambot.svg?branch=develop)](https://travis-ci.org/pluginsGLPI/telegrambot/) |

## Installation

Click on the image below to view the video preview of the installation process.

[![Everything Is AWESOME](http://img.youtube.com/vi/TKqIpIaAIAE/0.jpg)](https://youtu.be/TKqIpIaAIAE)

## Documentation

We maintain detailed documentation of the project on our website. See our [How-tos](https://pluginsGLPI.github.io/telegrambot/howtos) and [Development](https://pluginsGLPI.github.io/telegrambot/) sections.

## Versioning

This project adheres to [Semantic Versioning](http://semver.org/) to provide transparency in our release cycle and maintain backward compatibility. See [the tags section of our GitHub project](https://github.com/pluginsGLPI/telegrambot/tags) for changelogs for each release version.

## Contact

You can send us a message via [Telegram](https://telegram.me/tgbotglpi).

## Professional Services

GLPI Network services are available through our [Partner's Network](http://www.teclib-edition.com/en/partners/). We provide specialized training, bug fixes with editor subscription, contributions for new features, and more. Obtain a personalized service experience with associated benefits and opportunities.

## Contribute

If you want to report a bug, contribute code, or improve documentation, we welcome your contributions! Please read our [contributing guidelines](./CONTRIBUTING.md) and check out the issues in the [Issues Dashboard](https://github.com/pluginsGLPI/telegrambot/issues).

## Copying

- **Name**: [GLPI](http://glpi-project.org/) is a registered trademark of [Teclib'](http://www.teclib-edition.com/en/).
- **Code**: You can redistribute and/or modify it under the terms of the GNU General Public License ([GPLv3](https://www.gnu.org/licenses/gpl-3.0.en.html)).
- **Documentation**: Released under Attribution 4.0 International ([CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)).
