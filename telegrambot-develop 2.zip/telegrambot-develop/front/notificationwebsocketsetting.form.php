<?php

include ('../../../inc/includes.php');

Session::checkRight('config', UPDATE);
$notificationwebsocket = new PluginTelegrambotNotificationWebsocketSetting();

if (!empty($_POST['test_webhook_send'])) {
   PluginTelegrambotNotificationWebsocket::testNotification();
   header('Location: ' . $_SERVER['HTTP_REFERER']);
} else if (!empty($_POST['update'])) {
   PluginTelegrambotBot::setConfig('token', $_POST['token']);
   PluginTelegrambotBot::setConfig('bot_username', $_POST['bot_username']);
   // Salvar as configurações no banco de dados ou em um arquivo de configuração
   header('Location: ' . $_SERVER['HTTP_REFERER']);
}

Html::header(
   Notification::getTypeName(Session::getPluralNumber()),
   $_SERVER['PHP_SELF'],
   'config',
   'notification', 'config'
);

$notificationwebsocket->display(array('id' => 1));

Html::footer();
